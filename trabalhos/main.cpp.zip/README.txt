TECLADO:

Q - W : Move braço 3
A - S : Move braço 2
Z - X : Move braço 1

ESPAÇO Abre e fecha 
